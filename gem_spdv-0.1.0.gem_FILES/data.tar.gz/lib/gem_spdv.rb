require "gem_spdv/version"

module GemSpdv
  class Error < StandardError; end
  # Your code goes here...
end
